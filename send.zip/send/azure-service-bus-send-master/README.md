# azure-service-bus-send
This project can be used to send the data to azure bus - 
