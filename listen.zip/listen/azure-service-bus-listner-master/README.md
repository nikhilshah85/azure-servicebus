# azure-service-bus-listner
Azure service bus which acts as a listener and receives the data.
